#undef S_FUNCTION_NAME 
#define S_FUNCTION_NAME iir_filter_v1_sfunction        /* Name der S-Function festlegen */
#define S_FUNCTION_LEVEL 2

#include "simstruc.h"       /* wegen SimStruct S */
#include "coeff_iir.h"
#include "iir_filter_v1.h"

#define NENNER_COEFF_VECTOR_A ssGetSFcnParam(S,0)
#define ZAEHLER_COEFF_VECTOR_B ssGetSFcnParam(S,1)

static void mdlInitializeSizes(SimStruct *S)
{
    /*  In der Funktion mdlInitializeSizes m�ssen wir Simulink
     *  die Schnittstellen unseres Blockes mitteilen.
     *  D.h. wir sagen wieviele Ein- und Ausg�nge wir haben,
     *  welche Dimensionen diese Ports haben, welche Daten Simulink 
     *  f�r uns zwischen mehreren Zeitschritten 
     *  speichern muss, ob wir Parameter erwarten, usw.
     */
       
    ssSetNumSFcnParams(S, 2);  
    
    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

	ssSetNumRWork(S, 0);
    ssSetNumIWork(S, 0);
    ssSetNumPWork(S, 1); 
    
    if (!ssSetNumInputPorts(S, 1)) return;
    ssSetInputPortWidth(S, 0, 1);
    ssSetInputPortDirectFeedThrough(S, 0, 1);
     
    if (!ssSetNumOutputPorts(S, 1)) return;
    ssSetOutputPortWidth(S, 0, 1);

    ssSetInputPortDataType(S, 0, SS_DOUBLE);
    ssSetOutputPortDataType(S, 0, SS_DOUBLE); 
    
    ssSetNumSampleTimes(S, 1);
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

}


static void mdlInitializeSampleTimes(SimStruct *S)
{
    /* Mit der Funktion mdlInitializeSampleTimes teilen wir
     * Simulink mit, mit welcher Abtastrate unser Block ausgef�hrt werden 
     * soll. 
     * Hier gehen wir davon aus, dass der Simulink-Programmierer
     * das von oben her im Griff hat, d.h. wir erben einfach eine uns
     * zugewiesene Abtastrate (INHERITED_SAMPLE_TIME).
     */
    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
}


#define MDL_START 
#if defined(MDL_START) 
static void mdlStart(SimStruct *S)
{
   /* Die mdlStart wird einmalig zu Simulationsbeginn ausgef�hrt.
    * Dies ist ein sinnvoller Ort, um dynamisch Speicher zu reservieren.
    */
   int n; //Filterordnung
   real_T* akoeffizienten;
   real_T* bkoeffizienten;
   
   struct iir_filter_variablen * piir_filter_variablen;
   
   akoeffizienten = (real_T*)mxGetData(NENNER_COEFF_VECTOR_A);
   bkoeffizienten = (real_T*)mxGetData(ZAEHLER_COEFF_VECTOR_B);
   
   n = mxGetNumberOfElements(NENNER_COEFF_VECTOR_A)-1;
   
   piir_filter_variablen =(struct iir_filter_variablen *)malloc(sizeof(struct iir_filter_variablen));
   if(!piir_filter_variablen){
   
       ssSetErrorStatus(S,"Speicherreservierung fehlgeschlagen.");
       return;
   }
   
   if(alloc_iir_filter_variablen_struct(piir_filter_variablen,n) != RET_SUCCESS){
       /*Bei einem R�ckgabewert !=0 ist ein Fehler aufgetreten.*/
       
       free(piir_filter_variablen);
       ssSetErrorStatus(S,"Speicherrreservierung/Initialisierung fehlgeschlagen.");
       return;
      
   }
   
   setze_koeffizienten(piir_filter_variablen,(double *)akoeffizienten,(double *) bkoeffizienten);
   ssSetPWorkValue(S,0,piir_filter_variablen);
   
   
}
#endif

static void mdlOutputs(SimStruct *S, int_T tid)
{
   /* Die mdlOutputs wird in jedem Simulink-Zeitschritt ausgef�hrt.
    * Hier m�ssen aus den Eingangsdaten des S-Function-Blocks neue 
    * Ausgangsdaten berechnet werden.
    */
    
    real_T* aKoeffizienten;
    real_T* bKoeffizienten;
    real_T * y;
    InputRealPtrsType u;
    struct iir_filter_variablen * piir_filter_variablen;
    
    y = ssGetOutputPortRealSignal(S,0);
    u = ssGetInputPortRealSignalPtrs(S,0);
    aKoeffizienten = (real_T *)mxGetData(NENNER_COEFF_VECTOR_A);
    bKoeffizienten = (real_T *)mxGetData(ZAEHLER_COEFF_VECTOR_B);
    
    
    //Pointer auf vorab reservierten Speicher auslesen:
    
    piir_filter_variablen = (struct iir_filter_variablen *) ssGetPWorkValue(S,0);
    
    //Einlesen der aktuellen Koeffizienten:
    
    setze_koeffizienten(piir_filter_variablen,(double*) aKoeffizienten, (double *) bKoeffizienten);
    
    //Filterberechnung:
    
    filterausgabe_berechnen(piir_filter_variablen, *u[0],y);
   
   
}
     
static void mdlTerminate(SimStruct *S)
{
   /* Die Funktion mdlTerminate wird einmalig beim Beenden einer Simulation
    * ausgef�hrt. Dies ist ein sinnvoller Ort um den in der mdlStart 
    * reservierten Speicher wieder freizugeben.
    */
    
    
    
    int * Nullpointer;
    
    struct iir_filter_variablen * piir_filter_variablen;
    piir_filter_variablen = (struct iir_filter_variablen *) ssGetPWorkValue(S,0);
    
    if(piir_filter_variablen){
        //Gebe nicht mehr ben�tigten reservierten Speicher wieder frei
        
        free_iir_filter_variablen_struct(piir_filter_variablen);
        free(piir_filter_variablen);
    
    }
    
    Nullpointer = (int *) 0;
    ssSetPWorkValue(S, 0, Nullpointer);
    

    
}

/* S-Function trailer
 */
#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else                  
#include "cg_sfun.h"       /* Code generation registration function */
#endif                 
