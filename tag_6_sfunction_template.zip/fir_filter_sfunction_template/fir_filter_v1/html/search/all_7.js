var searchData=
[
  ['setze_5fkoeffizienten',['setze_koeffizienten',['../fir__filter__v1_8c.html#a5fe5a6711ed18792081d51c32a30db1c',1,'setze_koeffizienten(struct fir_filter_variablen *pfir_filter_variablen, double *aKoeffs):&#160;fir_filter_v1.c'],['../fir__filter__v1_8h.html#a5fe5a6711ed18792081d51c32a30db1c',1,'setze_koeffizienten(struct fir_filter_variablen *pfir_filter_variablen, double *aKoeffs):&#160;fir_filter_v1.c']]]
];
