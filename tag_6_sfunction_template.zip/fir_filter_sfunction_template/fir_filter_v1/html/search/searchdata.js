var indexSectionsWithContent =
{
  0: "abcdfnrsuxy",
  1: "f",
  2: "f",
  3: "afs",
  4: "abcdnuxy",
  5: "f",
  6: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator"
};

