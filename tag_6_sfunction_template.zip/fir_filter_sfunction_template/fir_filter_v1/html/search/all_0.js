var searchData=
[
  ['a',['A',['../structfir__filter__variablen.html#a9bef7177c8efcab68f5ae536ab41f68e',1,'fir_filter_variablen']]],
  ['alloc_5ffir_5ffilter_5fvariablen_5fstruct',['alloc_fir_filter_variablen_struct',['../fir__filter__v1_8c.html#abc92ffce07fa70fb21f22ed1c1365a93',1,'alloc_fir_filter_variablen_struct(struct fir_filter_variablen *pfir_filter_variablen, int iDimension):&#160;fir_filter_v1.c'],['../fir__filter__v1_8h.html#abc92ffce07fa70fb21f22ed1c1365a93',1,'alloc_fir_filter_variablen_struct(struct fir_filter_variablen *pfir_filter_variablen, int iDimension):&#160;fir_filter_v1.c']]]
];
