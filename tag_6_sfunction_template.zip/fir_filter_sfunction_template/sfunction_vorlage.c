#undef S_FUNCTION_NAME 
#define S_FUNCTION_NAME xxxxxxxxx        /* Name der S-Function festlegen */
#define S_FUNCTION_LEVEL 2

#include "simstruc.h"       /* wegen SimStruct S */

static void mdlInitializeSizes(SimStruct *S)
{
    /*  In der Funktion mdlInitializeSizes m�ssen wir Simulink
     *  die Schnittstellen unseres Blockes mitteilen.
     *  D.h. wir sagen wieviele Ein- und Ausg�nge wir haben,
     *  welche Dimensionen diese Ports haben, welche Daten Simulink 
     *  f�r uns zwischen mehreren Zeitschritten 
     *  speichern muss, ob wir Parameter erwarten, usw.
     */
       
    ssSetNumSFcnParams(S, 0);  
    
    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

	ssSetNumRWork(S, 0);
    ssSetNumIWork(S, 0);
    ssSetNumPWork(S, 0); 
    
    if (!ssSetNumInputPorts(S, 1)) return;
    ssSetInputPortWidth(S, 0, 1);
    ssSetInputPortDirectFeedThrough(S, 0, 1);
     
    if (!ssSetNumOutputPorts(S, 1)) return;
    ssSetOutputPortWidth(S, 0, 1);

    ssSetInputPortDataType(S, 0, SS_DOUBLE);
    ssSetOutputPortDataType(S, 0, SS_DOUBLE); 
    
    ssSetNumSampleTimes(S, 1);
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

}


static void mdlInitializeSampleTimes(SimStruct *S)
{
    /* Mit der Funktion mdlInitializeSampleTimes teilen wir
     * Simulink mit, mit welcher Abtastrate unser Block ausgef�hrt werden 
     * soll. 
     * Hier gehen wir davon aus, dass der Simulink-Programmierer
     * das von oben her im Griff hat, d.h. wir erben einfach eine uns
     * zugewiesene Abtastrate (INHERITED_SAMPLE_TIME).
     */
    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
}


#define MDL_START 
#if defined(MDL_START) 
static void mdlStart(SimStruct *S)
{
   /* Die mdlStart wird einmalig zu Simulationsbeginn ausgef�hrt.
    * Dies ist ein sinnvoller Ort, um dynamisch Speicher zu reservieren.
    */
        
}
#endif

static void mdlOutputs(SimStruct *S, int_T tid)
{
   /* Die mdlOutputs wird in jedem Simulink-Zeitschritt ausgef�hrt.
    * Hier m�ssen aus den Eingangsdaten des S-Function-Blocks neue 
    * Ausgangsdaten berechnet werden.
    */
   
   
}
     
static void mdlTerminate(SimStruct *S)
{
   /* Die Funktion mdlTerminate wird einmalig beim Beenden einer Simulation
    * ausgef�hrt. Dies ist ein sinnvoller Ort um den in der mdlStart 
    * reservierten Speicher wieder freizugeben.
    */
    

    
}

/* S-Function trailer
 */
#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else                  
#include "cg_sfun.h"       /* Code generation registration function */
#endif                 
